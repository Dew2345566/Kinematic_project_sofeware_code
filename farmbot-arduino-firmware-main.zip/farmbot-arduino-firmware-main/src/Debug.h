/*
* Debug.h
*
*  Created on: 2017/04/20
*      Author: Tim Evers
*/

#ifndef DEBUG_H_
#define debugMessages   false
#define debugInterrupt  false
#endif /* DEBUG_H_ */
