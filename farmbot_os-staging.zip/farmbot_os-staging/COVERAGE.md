# Coverage Stats

2021/10/28 - 64.3%

# Historic

Code coverage prior to conversion of app to monolith:

| Project               |1/1/20 |2/6/20 |3/4/20 |3/26/21|5/25/21|
|-----------------------|-------|-------|-------|-------|-------|
| farmbot_celery_script | 53.7% | 54.0% |54.0%  |73.8%  |73.8%  |
| farmbot_core          | 22.2% | 19.8% |26.3%  |45.5%  |51.3%  |
| farmbot_ext           | 53.6% | 52.7% |38.1%  |50.1%  |58.0%  |
| farmbot_os            | 22.0% | 27.6% |45.3%  |57.7%  |59.3%  |
| farmbot_telemetry     | ??.?% | ??.?% |??.?%  |41.4%  |41.4%  |

| Project               |5/25/21|6/16/21|
|-----------------------|-------|-------|
| farmbot_celery_script |73.8%  |74.1%  |
| farmbot_core          |51.3%  |53.4%  |
| farmbot_ext           |58.0%  |58.9%  |
| farmbot_os            |59.3%  |60.8%  |
| farmbot_telemetry     |41.4%  |41.4%  |

| Project               |9/23/21|9/24/21|
|-----------------------|-------|-------|
| farmbot_core          |59.4%  |59.6%  |
| farmbot_ext           |61.0%  |61.1%  |
| farmbot_os            |62.4%  |62.4%  |
| farmbot_telemetry     |41.4%  |58.3%  |
