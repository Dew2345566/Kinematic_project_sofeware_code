defmodule FarmbotOS.AssetHelperTest do
  use ExUnit.Case
end
