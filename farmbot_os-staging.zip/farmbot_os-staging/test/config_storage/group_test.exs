defmodule FarmbotOS.Config.GroupTest do
  use ExUnit.Case
end
