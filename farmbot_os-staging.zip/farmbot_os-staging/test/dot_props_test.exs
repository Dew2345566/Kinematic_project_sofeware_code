defmodule FarmbotOS.Celery.DotPropsTest do
  use ExUnit.Case
  doctest FarmbotOS.Celery.DotProps, import: true
end
